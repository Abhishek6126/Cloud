# test_energy_model.py

